# ZYRON SENSI Bot — protótipo

Bot inicial para o servidor **ZYRON SENSI - FREE FIRE**.

## Comandos
- `/painel` — publica um painel com botão para abrir tickets privados.
- `/regras` — publica regras básicas.
- `/catalogo` — publica um catálogo demonstrativo.

## Tickets
- Cada pessoa pode ter um ticket aberto por vez.
- O botão **Fechar ticket** permite que quem abriu ou a equipe feche o canal.
- Opcionalmente, configure `SUPPORT_ROLE_ID` com o ID do cargo da equipe para que esse cargo veja os tickets.
- Sem `SUPPORT_ROLE_ID`, somente o autor do ticket e o bot terão acesso por padrão; administradores com permissões apropriadas ainda podem gerenciar o servidor.

## Configuração
1. Use Python 3.10 ou superior.
2. Instale as dependências: `pip install -r requirements.txt`
3. Configure `DISCORD_TOKEN` nas variáveis de ambiente da hospedagem.
4. Opcional: configure `GUILD_ID` para sincronizar comandos rapidamente no servidor de teste.
5. Opcional: configure `SUPPORT_ROLE_ID` com o ID numérico do cargo de suporte.
6. Inicie com `python bot.py`.

No Discord Developer Portal, convide o bot com os escopos `bot` e `applications.commands`. Dê as permissões necessárias: Ver canais, Enviar mensagens, Incorporar links, Ler histórico de mensagens e Gerenciar canais.

## Importante
- Os preços do catálogo são demonstrativos; altere-os antes de divulgar.
- Este protótipo não processa pagamentos nem entrega packs automaticamente.
- Teste primeiro em um servidor privado.
- Nunca publique nem envie o token do bot. Se vazar, regenere-o no Discord Developer Portal → Bot.
